package com.Mavel.ProjectoFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectoFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
